﻿'******************************************************************************
'
'                          Copyright Notice
'   This software is open source and is provided by Omni Embedded, LLC, 
'   http://www.omniembedded.com/
'   No warranty exists.  Use at your own peril.
'
'******************************************************************************
'
' Basic Programming Rules '
Option Strict On
Option Explicit On
'
' Imports '
Imports System.IO
Imports System.Threading
Imports System.Windows.Forms
'
'******************************************************************************
'                              makeV
''' <summary>
''' This executable is called as a substitute for the make.exe call from the
''' Eclipse IDE.  It receives the make.exe pass parameters and then executes
''' the pre-build and main-build as seperate steps.  Eclipse has an issue where
''' if running parallel processes it starts the main build before the pre-build
''' has completed.  This corrects that issue.
''' 
''' The Eclipse setup is set to call mainV.exe rather than main.exe.  This executable
''' must reside in the same folder as the main.exe.
''' </summary>
Public Module makeV
    ' ------------------------------------------------------------------------
    ' ------------------------------------------------------------------------
    ' ------------------------------------------------------------------------
    '// Definitions \\'

    ' ------------------------------------------------------------------------
    ' ------------------------------------------------------------------------
    ' ------------------------------------------------------------------------
    '// Constants \\'

    '-------------------------------------------------------------------------
    ' ------------------------------------------------------------------------
    ' ------------------------------------------------------------------------
    '// Private variables \\'

    ' ------------------------------------------------------------------------
    ' ------------------------------------------------------------------------
    ' ------------------------------------------------------------------------
    '// Public methods \\'
    '******************************************************************************
    Function Main() As Integer
#If DEBUG Then
        Dim passParList As New List(Of String) '= {"-j8", "pre-build", "main-build"}
        passParList.Add("makeV")
        'passParList.Add("-j8")
        passParList.Add("pre-build")
        passParList.Add("main-build")
        'passParList.Add("clean")
#Else
        Dim passParList As New List(Of String)
        passParList.AddRange(Environment.GetCommandLineArgs.ToList)
#End If
        ' passPars(0) = -j? - signifies number of parallel builds (is missing if not set for parallel builds)
        ' passPars(1) = cmd 1
        ' passPars(2) = cmd 2
        ' passPar(n)
        Dim myProcess As System.Diagnostics.Process = System.Diagnostics.Process.GetCurrentProcess()
        myProcess.PriorityClass = System.Diagnostics.ProcessPriorityClass.High
        Dim returnVal As Integer = 0
        Dim doParallelBuild As Boolean = passParList(1).Trim.StartsWith("-j")
        Dim makePathNameRoot As String = Application.StartupPath + "\make.exe"

        Try
            If Not doParallelBuild Then
                For lpIndx = 1 To (passParList.Count - 1)
                    Dim makePathName = makePathNameRoot + " " + passParList(lpIndx)
                    Shell(makePathName, AppWinStyle.Hide, True)
                Next
            Else
                For lpIndx = 2 To (passParList.Count - 1)
                    Dim makePathName = makePathNameRoot + " " + passParList(1) + " " + passParList(lpIndx)
                    Shell(makePathName, AppWinStyle.Hide, True)
                    Thread.Sleep(1000)
                Next
            End If
        Catch ex As Exception
            Console.Write("makeV build process failed, " + ex.Message + vbCrLf)
            returnVal = -1
        End Try

        Return returnVal
    End Function
    ' ------------------------------------------------------------------------
    ' ------------------------------------------------------------------------
    ' ------------------------------------------------------------------------
    '// Private methods \\'
    '******************************************************************************


End Module

